GREGORY BRISEBOIS
CS124 DATA STRUCTURES LAB
WITH PROFESSOR KAMRAN EFTEKARI

- COMPILE INSTRUCTIONS:

There is only one source file, 'expression.cpp'.  Everything else is in .h files 
which are included in the source file.  To compile the program, you only need to
compile 'expression.cpp'.  For instance, in gcc, run:

g++ expression.cpp

and then run the executable 'a.out' to run the compiled program.

- RUNNING INSTRUCTIONS

The program follows the assignment prompt; it will take a (assumingly valid) 
expression and evaluate it, printing out the stack and queue contents in the
process.
